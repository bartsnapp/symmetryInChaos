import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class SymmetricChaos {

    public final static int width = 175;
    public final static int height = 175;
    public final static double xmin = -.8;
    public final static double xmax = .8;
    public final static double xwidth = xmax - xmin;
    public final static double ymin = -.8;
    public final static double ymax = .8;
    public final static double ywidth = ymax - ymin;
    public final static int table[][] = new int[height][width];

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private SymmetricChaos() {
    }

    //w needs to be stored as a complex with its input value as the imaginary component.
    public static Complex f(int n, double a, double b, double g, double w,
            double l, Complex z) {

        Complex unit1 = new Complex(1, 0);
        Complex unit2 = new Complex(0, 1);
        Complex result = ((unit1.scale(l))
                .plus((z.times(z.conjugate())).scale(a))
                .plus(unit1.scale(z.pow(n).re() * b + w))).times(z)
                        .plus(z.conjugate().pow(n - 1).scale(g));

        return result;
    }

    public static double getInfo(SimpleReader in, SimpleWriter out) {
        String variable = in.nextLine();

        return Double.parseDouble(variable);

    }

    public static int xpos(Complex z) {
        return (int) (width * (z.re() - xmin) / xwidth);
    }

    public static int ypos(Complex z) {
        return (int) (height * (z.im() - ymin) / ywidth);
    }

    public static void main(String[] args) {

        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        Complex z = new Complex(.5, .5);
        int n = 6;
        double a = 5;
        double b = 1.5;
        double g = 1;
        double w = 0;
        double l = -2.7;

//
//        out.println("n=");
//        int n = Integer.parseInt(in.nextLine());
//        out.println("Alpha = ");
//        Complex a = new Complex(getInfo(in, out), 0);
//        out.println("Beta = ");
//        Complex b = new Complex(getInfo(in, out), 0);
//        out.println("Gamma = ");
//        Complex g = new Complex(getInfo(in, out), 0);
//        out.println("Omega = ");
//        Complex w = new Complex(0, getInfo(in, out));
//        out.println("Lambda = ");
//        Complex l = new Complex(getInfo(in, out), 0);
//        out.println("Z real = ");
//        double zreal = getInfo(in, out);
//        out.println("Z imaginary = ");
//        double zimag = getInfo(in, out);
//
//        Complex z = new Complex(zreal, zimag);
//
//        //now we have all the variables and the function
//
        out.println("iterations = ");
        int iterations = Integer.parseInt(in.nextLine());

        int i = 0;
        while (i < iterations) {
            int x = xpos(z);
            int y = ypos(z);
            table[y][x] = table[y][x] + 1;

            i++;
            z = f(n, a, b, g, w, l, z);

        }

//        int x = 0;
//        int y = 0;
//        while (y < height) {
//            out.print("[ ");
//            while (x < width) {
//                if (table[y][x] == 0) {
//                    out.print("   ");
//                } else {
//                    System.err.print(table[y][x] + ",");
//                }
//                x++;
//            }
//            out.print("]");
//            x = 0;
//            out.print("\n");
//            y++;
//        }

        int x = 0;
        int y = 0;
        while (y < height) {
            out.print("[ ");
            while (x < width) {
                if (table[y][x] > 10000) {
                    out.print("@@@");
                } else if (table[y][x] > 1000) {
                    out.print("###");
                } else if (table[y][x] > 100) {
                    out.print("///");

                } else if (table[y][x] > 10) {
                    out.print("|||");

                } else if (table[y][x] == 0) {
                    out.print("   ");

                }
                x++;
            }
            out.print("]");
            x = 0;
            out.print("\n");
            y++;
        }

        in.close();
        out.close();
    }

}
